# Instruções para Publicação e Manutenção do Website BUDAMOR

## Visão Geral do Website

O website BUDAMOR foi desenvolvido utilizando React e Tailwind CSS, criando uma presença online sofisticada e profissional para o gabinete terapêutico. O site inclui as seguintes páginas:

1. **Página Inicial (Home)**: Apresentação do gabinete, visão geral dos serviços e testemunho de cliente
2. **Serviços**: Descrição detalhada de cada terapia oferecida, incluindo preços
3. **Sobre**: Informações sobre a missão, visão, valores e a terapeuta Dra. Dora
4. **Contacto**: Formulário de contacto, informações de localização, horário e redes sociais

O design segue a identidade visual do BUDAMOR, utilizando o esquema de cores preto e dourado do logótipo, transmitindo sofisticação, tranquilidade e exclusividade.

## Ficheiros do Website

O website está organizado da seguinte forma:

- `/dist`: Pasta contendo a versão compilada e otimizada do site, pronta para publicação
- `/src`: Código-fonte do website
  - `/components`: Componentes reutilizáveis (Navbar, Footer, etc.)
  - `/pages`: Páginas principais do site
  - `/lib`: Utilitários e configurações (tema, etc.)
  - `/assets`: Recursos estáticos

## Instruções para Publicação

### Opção 1: Publicação em Serviço de Hospedagem Web

1. Contrate um serviço de hospedagem web (recomendações: Netlify, Vercel, ou qualquer hospedagem tradicional)
2. Faça upload da pasta `/dist` completa para o servidor de hospedagem
3. Configure o domínio desejado (recomendamos `budamor.pt` ou similar)
4. Certifique-se de que o servidor está configurado para servir uma aplicação de página única (SPA)

### Opção 2: Publicação via GitHub Pages

1. Crie uma conta no GitHub se ainda não tiver
2. Crie um novo repositório para o website
3. Faça upload dos ficheiros do projeto
4. Configure o GitHub Pages para servir a partir da pasta `/dist`
5. O site estará disponível em `seuusername.github.io/nome-do-repositorio`

## Instruções para Manutenção

### Atualização de Conteúdo

Para atualizar o conteúdo do website:

1. Modifique os ficheiros relevantes na pasta `/src/pages`
2. Execute `pnpm run build` para gerar uma nova versão compilada
3. Faça upload da pasta `/dist` atualizada para o servidor

### Adição de Novas Páginas

Para adicionar novas páginas ao website:

1. Crie um novo ficheiro na pasta `/src/pages` (ex: `Eventos.tsx`)
2. Adicione a rota correspondente em `/src/main.tsx`
3. Adicione o link na navegação em `/src/components/layout/Navbar.tsx` e `/src/components/layout/Footer.tsx`
4. Execute `pnpm run build` e faça upload da versão atualizada

### Otimização para Motores de Busca (SEO)

Para melhorar o SEO do website:

1. Registe o site no Google Search Console e Bing Webmaster Tools
2. Crie um ficheiro `sitemap.xml` na pasta `/public` antes de compilar
3. Adicione meta tags relevantes no ficheiro `index.html`
4. Considere adicionar conteúdo regular ao site (blog, artigos, etc.)

## Recomendações Adicionais

1. **Google Meu Negócio**: Complete o perfil do BUDAMOR no Google Meu Negócio e adicione o URL do website
2. **Redes Sociais**: Adicione o link do website nas biografias das redes sociais
3. **Análise de Tráfego**: Implemente o Google Analytics para monitorizar o desempenho do site
4. **Backup Regular**: Mantenha cópias de segurança do código-fonte e da versão compilada

## Suporte Técnico

Para qualquer dúvida ou assistência técnica relacionada com o website, entre em contacto com o desenvolvedor.

---

Este website foi desenvolvido com atenção aos detalhes e alinhado com a identidade visual premium do BUDAMOR, garantindo uma experiência de utilizador intuitiva e sofisticada que reflete a qualidade dos serviços oferecidos pelo gabinete terapêutico.
