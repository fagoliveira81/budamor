import Footer from '../components/layout/Footer';
import Navbar from '../components/layout/Navbar';

const Servicos = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        {/* Header */}
        <section className="bg-black text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-serif mb-6 text-gold">
              Os Nossos Serviços
            </h1>
            <p className="text-xl max-w-3xl mx-auto">
              No BUDAMOR, oferecemos uma variedade de terapias e práticas para promover o seu bem-estar emocional, 
              mental e espiritual. Cada serviço é personalizado para atender às suas necessidades específicas.
            </p>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 gap-16">
              {/* Service 1 */}
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 bg-black rounded-lg p-8 flex items-center justify-center">
                  <h2 className="text-3xl font-serif text-gold text-center">Terapia Individual</h2>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    A terapia individual é um espaço seguro e confidencial onde pode explorar questões pessoais, 
                    emocionais e comportamentais que estejam a causar desconforto ou limitações na sua vida.
                  </p>
                  <p className="text-gray-700 mb-4">
                    Através de uma abordagem integrativa e personalizada, ajudamos a desenvolver maior autoconhecimento, 
                    identificar padrões limitantes e construir estratégias eficazes para lidar com desafios como:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-700">
                    <li>Ansiedade e stress</li>
                    <li>Depressão e tristeza persistente</li>
                    <li>Traumas e experiências difíceis</li>
                    <li>Questões de autoestima e autoconfiança</li>
                    <li>Transições de vida e tomadas de decisão</li>
                  </ul>
                  <p className="text-gray-700 mb-4">
                    <strong>Duração:</strong> 50 minutos
                  </p>
                  <p className="text-gray-700">
                    <strong>Valor:</strong> 50€ por sessão
                  </p>
                </div>
              </div>

              {/* Service 2 */}
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 bg-black rounded-lg p-8 flex items-center justify-center">
                  <h2 className="text-3xl font-serif text-gold text-center">Terapia de Casal</h2>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    A terapia de casal oferece um ambiente neutro e apoiante onde os parceiros podem explorar 
                    e resolver conflitos, melhorar a comunicação e fortalecer a sua conexão emocional.
                  </p>
                  <p className="text-gray-700 mb-4">
                    Trabalhamos em conjunto para:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-700">
                    <li>Desenvolver habilidades de comunicação eficaz</li>
                    <li>Identificar e modificar padrões de interação negativos</li>
                    <li>Reconstruir a confiança e a intimidade</li>
                    <li>Navegar por transições de vida e desafios como casal</li>
                    <li>Resolver conflitos de forma construtiva</li>
                  </ul>
                  <p className="text-gray-700 mb-4">
                    <strong>Duração:</strong> 60 minutos
                  </p>
                  <p className="text-gray-700">
                    <strong>Valor:</strong> 50€ por sessão
                  </p>
                </div>
              </div>

              {/* Service 3 */}
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 bg-black rounded-lg p-8 flex items-center justify-center">
                  <h2 className="text-3xl font-serif text-gold text-center">Hipnoterapia Quântica</h2>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    A Hipnoterapia Quântica é uma abordagem poderosa que combina técnicas avançadas de hipnose 
                    com princípios da física quântica, permitindo acessar e reprogramar padrões subconscientes 
                    que influenciam a sua vida.
                  </p>
                  <p className="text-gray-700 mb-4">
                    Esta terapia é particularmente eficaz para:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-700">
                    <li>Libertar crenças limitantes e bloqueios emocionais</li>
                    <li>Transformar hábitos indesejados</li>
                    <li>Acessar recursos internos e potenciais inexplorados</li>
                    <li>Promover cura emocional profunda</li>
                    <li>Expandir a consciência e a percepção da realidade</li>
                  </ul>
                  <p className="text-gray-700 mb-4">
                    <strong>Duração:</strong> 60 minutos
                  </p>
                  <p className="text-gray-700">
                    <strong>Valor:</strong> 50€ por sessão
                  </p>
                </div>
              </div>

              {/* Service 4 */}
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 bg-black rounded-lg p-8 flex items-center justify-center">
                  <h2 className="text-3xl font-serif text-gold text-center">EFT (Técnica de Libertação Emocional)</h2>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    A Técnica de Libertação Emocional (EFT) combina princípios da acupuntura com psicologia moderna, 
                    sem utilizar agulhas. Através de toques suaves em pontos específicos do corpo enquanto focamos 
                    em pensamentos ou emoções desafiadoras, podemos reduzir significativamente a intensidade emocional.
                  </p>
                  <p className="text-gray-700 mb-4">
                    O EFT é especialmente útil para:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-700">
                    <li>Reduzir rapidamente a ansiedade e o stress</li>
                    <li>Aliviar medos e fobias</li>
                    <li>Processar e libertar traumas</li>
                    <li>Diminuir a intensidade de dores físicas</li>
                    <li>Superar bloqueios emocionais</li>
                  </ul>
                  <p className="text-gray-700 mb-4">
                    <strong>Duração:</strong> 50 minutos
                  </p>
                  <p className="text-gray-700">
                    <strong>Valor:</strong> 50€ por sessão
                  </p>
                </div>
              </div>

              {/* Service 5 */}
              <div className="flex flex-col md:flex-row gap-8">
                <div className="md:w-1/3 bg-black rounded-lg p-8 flex items-center justify-center">
                  <h2 className="text-3xl font-serif text-gold text-center">Meditação</h2>
                </div>
                <div className="md:w-2/3">
                  <p className="text-gray-700 mb-4">
                    As nossas sessões de meditação guiada oferecem um espaço para acalmar a mente, 
                    reduzir o stress e desenvolver maior consciência e equilíbrio interior.
                  </p>
                  <p className="text-gray-700 mb-4">
                    Benefícios da prática regular de meditação:
                  </p>
                  <ul className="list-disc pl-6 mb-4 text-gray-700">
                    <li>Redução significativa dos níveis de stress e ansiedade</li>
                    <li>Melhoria da concentração e clareza mental</li>
                    <li>Aumento da autoconsciência e autocontrolo</li>
                    <li>Promoção de um sono mais reparador</li>
                    <li>Desenvolvimento de maior resiliência emocional</li>
                  </ul>
                  <p className="text-gray-700 mb-4">
                    <strong>Duração:</strong> 45 minutos
                  </p>
                  <p className="text-gray-700 mb-4">
                    <strong>Valor:</strong> 10€ por sessão individual ou em grupo
                  </p>
                  <p className="text-gray-700">
                    <strong>Pacotes mensais:</strong>
                    <ul className="list-disc pl-6 mt-2 text-gray-700">
                      <li>1 vez por semana: 35€/mês</li>
                      <li>2 vezes por semana: 45€/mês</li>
                      <li>3 vezes por semana: 50€/mês</li>
                    </ul>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-black text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-serif mb-6 text-gold">
              Pronto para Iniciar a Sua Jornada de Transformação?
            </h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Agende a sua primeira consulta ou sessão e dê o primeiro passo em direção ao bem-estar.
            </p>
            <a
              href="/contacto"
              className="bg-gold text-black px-8 py-3 rounded-md hover:bg-gold-light transition-colors font-medium"
            >
              Contacte-nos Hoje
            </a>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Servicos;
