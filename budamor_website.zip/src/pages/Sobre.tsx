import Footer from '../components/layout/Footer';
import Navbar from '../components/layout/Navbar';

const Sobre = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        {/* Header */}
        <section className="bg-black text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-serif mb-6 text-gold">
              Sobre o BUDAMOR
            </h1>
            <p className="text-xl max-w-3xl mx-auto">
              Um espaço dedicado ao bem-estar emocional e ao equilíbrio interior, 
              onde cada pessoa é acolhida na sua individualidade.
            </p>
          </div>
        </section>

        {/* About Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-12">
              <div className="md:w-1/2">
                <h2 className="text-3xl font-serif mb-6 text-gold">A Nossa Missão</h2>
                <p className="text-gray-700 mb-4">
                  No BUDAMOR, acreditamos que cada pessoa possui em si todos os recursos necessários 
                  para uma vida plena e equilibrada. A nossa missão é ajudar a despertar esses recursos, 
                  facilitando um processo de autoconhecimento e transformação que permita superar 
                  limitações, curar feridas emocionais e expandir o potencial humano.
                </p>
                <p className="text-gray-700 mb-4">
                  Trabalhamos com uma abordagem integrativa que respeita a unicidade de cada indivíduo, 
                  combinando diferentes técnicas e metodologias para criar um percurso terapêutico 
                  personalizado e eficaz.
                </p>
                <p className="text-gray-700">
                  O nosso compromisso é proporcionar um espaço seguro, acolhedor e livre de julgamentos, 
                  onde cada pessoa possa explorar o seu mundo interior e encontrar o seu próprio caminho 
                  para o bem-estar e a realização pessoal.
                </p>
              </div>
              <div className="md:w-1/2">
                <h2 className="text-3xl font-serif mb-6 text-gold">A Nossa Visão</h2>
                <p className="text-gray-700 mb-4">
                  Aspiramos a ser um centro de referência em Viseu no âmbito do desenvolvimento pessoal 
                  e bem-estar emocional, contribuindo para uma sociedade mais consciente, compassiva e 
                  emocionalmente equilibrada.
                </p>
                <p className="text-gray-700 mb-4">
                  Acreditamos que ao promover a saúde mental e emocional de cada indivíduo, estamos a 
                  contribuir para relações mais saudáveis, famílias mais harmoniosas e comunidades mais 
                  resilientes.
                </p>
                <p className="text-gray-700">
                  A nossa visão é de um mundo onde cada pessoa tenha acesso às ferramentas e ao apoio 
                  necessários para cultivar paz interior, autoconhecimento e realização pessoal, 
                  independentemente das circunstâncias externas.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Therapist Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-serif text-center mb-12 text-gold">
              Conheça a Nossa Terapeuta
            </h2>
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/3 flex justify-center">
                <div className="w-64 h-64 rounded-full bg-black flex items-center justify-center">
                  <span className="text-gold text-xl">Dra. Dora de Oliveira</span>
                </div>
              </div>
              <div className="md:w-2/3">
                <h3 className="text-2xl font-serif mb-4 text-gold">Dra. Dora de Oliveira</h3>
                <p className="text-gray-700 mb-4">
                  Mestre em Psicologia Clínica e da Saúde, a Dra. Dora de Oliveira dedica-se há vários anos 
                  ao estudo e prática de diversas abordagens terapêuticas, com especial foco nos transtornos 
                  de ansiedade e depressão.
                </p>
                <p className="text-gray-700 mb-4">
                  Especialista em Hipnoterapia e na Técnica de Libertação Emocional (EFT), a Dra. Dora 
                  combina o conhecimento científico da psicologia com práticas complementares que visam 
                  promover uma transformação profunda e duradoura.
                </p>
                <p className="text-gray-700 mb-4">
                  A sua abordagem caracteriza-se pela empatia, respeito e um profundo compromisso com o 
                  bem-estar dos seus clientes. Acredita que cada pessoa é única e, como tal, merece um 
                  acompanhamento personalizado que respeite o seu ritmo e as suas necessidades específicas.
                </p>
                <p className="text-gray-700">
                  No BUDAMOR, a Dra. Dora criou um espaço que reflete a sua filosofia de trabalho: 
                  acolhedor, tranquilo e propício à introspecção e ao autoconhecimento.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-serif text-center mb-12 text-gold">
              Os Nossos Valores
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Respeito</h3>
                <p className="text-gray-700">
                  Honramos a individualidade e o percurso único de cada pessoa, 
                  respeitando as suas crenças, valores e escolhas sem julgamento.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Empatia</h3>
                <p className="text-gray-700">
                  Cultivamos a capacidade de compreender profundamente a experiência 
                  do outro, criando um espaço de acolhimento e compreensão.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Integridade</h3>
                <p className="text-gray-700">
                  Atuamos com honestidade, transparência e compromisso ético em todas 
                  as nossas interações e práticas terapêuticas.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Confidencialidade</h3>
                <p className="text-gray-700">
                  Garantimos a total privacidade e sigilo de todas as informações 
                  partilhadas durante o processo terapêutico.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Excelência</h3>
                <p className="text-gray-700">
                  Buscamos constantemente o aperfeiçoamento das nossas práticas e 
                  conhecimentos para oferecer o melhor serviço possível.
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Compaixão</h3>
                <p className="text-gray-700">
                  Abordamos cada pessoa e situação com um coração aberto, reconhecendo 
                  a humanidade compartilhada em todas as experiências.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-black text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-serif mb-6 text-gold">
              Venha Conhecer o BUDAMOR
            </h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto">
              Estamos localizados no centro de Viseu, num espaço tranquilo e acolhedor, 
              projetado para proporcionar uma experiência de bem-estar desde o primeiro momento.
            </p>
            <a
              href="/contacto"
              className="bg-gold text-black px-8 py-3 rounded-md hover:bg-gold-light transition-colors font-medium"
            >
              Agende uma Visita
            </a>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Sobre;
