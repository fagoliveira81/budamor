import Footer from '../components/layout/Footer';
import Navbar from '../components/layout/Navbar';

const Home = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-black text-white py-20">
          <div className="container mx-auto px-4 flex flex-col items-center text-center">
            <h1 className="text-4xl md:text-5xl font-serif mb-6 text-gold">
              BUDAMOR Gabinete Terapêutico
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl">
              Um espaço dedicado ao seu bem-estar emocional e equilíbrio interior
            </p>
            <a
              href="/contacto"
              className="bg-gold text-black px-8 py-3 rounded-md hover:bg-gold-light transition-colors font-medium"
            >
              Marque a sua consulta
            </a>
          </div>
        </section>

        {/* Services Overview */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-serif text-center mb-12 text-black">
              Os Nossos Serviços
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Service 1 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Terapia Individual</h3>
                <p className="text-gray-700">
                  Sessões personalizadas para ajudar a superar desafios emocionais, 
                  ansiedade, depressão e promover o autoconhecimento.
                </p>
              </div>

              {/* Service 2 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Terapia de Casal</h3>
                <p className="text-gray-700">
                  Facilitamos a comunicação e a resolução de conflitos, ajudando a 
                  construir relacionamentos mais saudáveis e satisfatórios.
                </p>
              </div>

              {/* Service 3 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Hipnoterapia Quântica</h3>
                <p className="text-gray-700">
                  Uma abordagem poderosa que combina hipnose e princípios quânticos para 
                  transformar padrões subconscientes limitantes.
                </p>
              </div>

              {/* Service 4 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">EFT (Técnica de Libertação Emocional)</h3>
                <p className="text-gray-700">
                  Método eficaz para libertar bloqueios emocionais e reduzir o stress 
                  através de toques suaves em pontos específicos do corpo.
                </p>
              </div>

              {/* Service 5 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Meditação</h3>
                <p className="text-gray-700">
                  Sessões guiadas para acalmar a mente, reduzir o stress e desenvolver 
                  maior consciência e equilíbrio interior.
                </p>
              </div>

              {/* Service 6 */}
              <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-serif mb-3 text-gold">Consultas Online</h3>
                <p className="text-gray-700">
                  Todos os nossos serviços estão disponíveis em formato online, 
                  proporcionando flexibilidade e conforto.
                </p>
              </div>
            </div>
            <div className="text-center mt-10">
              <a
                href="/servicos"
                className="text-gold hover:text-gold-light transition-colors font-medium"
              >
                Ver todos os serviços →
              </a>
            </div>
          </div>
        </section>

        {/* Testimonial Section */}
        <section className="py-16 bg-black text-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-serif text-center mb-12 text-gold">
              O Que Dizem os Nossos Clientes
            </h2>
            <div className="max-w-3xl mx-auto">
              <div className="bg-black-light p-8 rounded-lg border border-gold">
                <p className="italic text-lg mb-6">
                  "As sessões de meditação no BUDAMOR transformaram a minha forma de lidar com o stress diário. 
                  A Dora tem uma capacidade única de criar um ambiente de total tranquilidade e acolhimento. 
                  Recomendo vivamente a quem procura equilíbrio emocional."
                </p>
                <p className="text-gold font-medium">— Maria S., Viseu</p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-serif mb-6 text-black">
              Comece a Sua Jornada de Bem-Estar Hoje
            </h2>
            <p className="text-xl mb-8 max-w-3xl mx-auto text-gray-700">
              Dê o primeiro passo em direção a uma vida mais equilibrada e consciente.
            </p>
            <a
              href="/contacto"
              className="bg-gold text-black px-8 py-3 rounded-md hover:bg-gold-light transition-colors font-medium"
            >
              Agende a Sua Primeira Sessão
            </a>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Home;
